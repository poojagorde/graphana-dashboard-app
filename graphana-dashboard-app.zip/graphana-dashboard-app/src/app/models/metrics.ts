export class Metrics {
    id: number = 0;
    title: string = "";
    value: string = "";
    cols: number = 3;
    rows: number = 1;
}
