import { Metrics } from './metrics';

describe('Metrics', () => {
  it('should create an instance', () => {
    expect(new Metrics()).toBeTruthy();
  });
});
